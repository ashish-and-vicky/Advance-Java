/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reportdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java_cup.Main;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author student
 */
public class ReportDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            System.out.println(con);
            JasperPrint jasperPrint = JasperFillManager.fillReport("report2.jasper", new HashMap(),con);
            JasperExportManager.exportReportToPdfFile(jasperPrint,
                            "/Test.pdf");
            JasperViewer.viewReport(jasperPrint, false);
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
